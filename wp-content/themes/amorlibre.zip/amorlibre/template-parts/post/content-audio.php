<?php
/**
 * Created by PhpStorm.
 * User: lingardssonluna
 * Date: 2018-04-25
 * Time: 14:35
 * @package Wordpress
 * @subpackage amorlibre
 * This template is for displaying audio posts
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

</article>
