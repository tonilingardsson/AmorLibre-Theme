<?php
/**
 * Created by PhpStorm.
 * User: lingardssonluna
 * Date: 2018-04-25
 * Time: 08:35
 * @package Wordpress
 *  * @subpackage amorlibre
 * Displays header media. Print the markup in the Customizer preview.
 */
?>
<div class="customer-header">
    <div class="customer-header-media">
        <?php the_custom_header_markup(); ?>
    </div>
</div>
