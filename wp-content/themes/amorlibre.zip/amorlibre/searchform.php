<?php
/**
 * The template for displaying all single posts
 *
 * @package WordPress
 * @subpackage amorlibre
 */
echo "Search form";
?>