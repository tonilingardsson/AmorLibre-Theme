<?php
/**
 * The template for displaying all single posts
 *
 * @package WordPress
 * @subpackage amorlibre
 */

get_header(); 
?>

<div class="wrapp">
    <div id="primary" class="content-area">
        <main id="primary" class="site-main" role="main">
            <p>PHP while loop for posts</p>
        </main>
    </div>
</div>


<?php
get_footer();